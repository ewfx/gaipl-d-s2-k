Replace this file with files that you would like to use for your demo. This may include

- A presentation/deck in pdf or pptx format
- A demo video (screen capture) in mp4 or other popular video formats
- Any other document describing your solution (in pdf or md format)