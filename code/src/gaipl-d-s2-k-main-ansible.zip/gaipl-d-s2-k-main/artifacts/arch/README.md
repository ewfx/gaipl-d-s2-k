Replace this file with a document that describes the architecture and design of your solution architecture. This may include
    - An architecture drawing exported into a png/jpeg format image
    - A document in pdf or md format that describes your solution